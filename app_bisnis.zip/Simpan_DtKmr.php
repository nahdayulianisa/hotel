<?php

//include_once('koneksi.php');
include ("koneksi.php");
$nameFile = $_FILES['gambar']['name'];
$tmp = $_FILES['gambar']['tmp_name'];
 
$path = "images/";
 
$extenstion = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
 
if ($_FILES['gambar']['size'] > 512000) {
    echo "File terlalu besar";
    return;
}
 

 
$save = move_uploaded_file($tmp, $path . $nameFile);
if ($save) {
    $kd_kmr = $_POST['kd_kmr'];
	$nm_kmr = $_POST['nm_kmr'];
	$hrg_kmr = $_POST['hrg_kmr'];
	$fasilitas = $_POST ['fasilitas'];
	$gambar = $_FILES['gambar']['name'];
    $sql = "insert into tb_indtkmr (kd_kmr,nm_kmr,hrg_kmr,fasilitas,gambar)" . 
    "values ( '$kd_kmr','$nm_kmr','$hrg_kmr','$fasilitas','$gambar')";
    $save = mysqli_query($conn, $sql);
    echo "File berhasil di upload<br>";
	header("location: InputDtKmr.php");
} else {
    echo "Upload FIle gagal.";
 }
 
 
//include_once('koneksi.php');



//if(isset($_POST["save"])){
	//$kd_kmr = $_POST['kd_kmr'];
	//$jml_kmr = $_POST['jml_kmr'];
	//$hrg_kmr = $_POST['hrg_kmr'];
	////$fasilitas = $_POST ['fasilitas'];
    //$move = move_uploaded_file($_FILES['gambar']['tmp_name'], 'C:/xampp/htdocs/app_bisnis/image/'.$fileName); //save image to the folder

 //if(!empty($kd_kmr)){
  //$sql = "insert into tb_indtkmr ( kd_kmr,jml_kmr,hrg_kmr,fasilitas,gambar)" . 
    //"values ( '$kd_kmr','$jml_kmr','$hrg_kmr','$fasilitas','$gambar')";
  //mysqli_query($conn, $sql);
  //header('location:InputDtKmr.php');
 //}else{
  //echo 'Semua data diperlukan. Harap isi semua.!';
 //}
//}
?>