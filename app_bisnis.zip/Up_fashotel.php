<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>INPUT DATA FASILITAS HOTEL</title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- styles -->
  <link href="assets/css/bootstrap.css" rel="stylesheet">
  <link href="assets/css/bootstrap-responsive.css" rel="stylesheet">
  <link href="assets/css/docs.css" rel="stylesheet">
  <link href="assets/css/prettyPhoto.css" rel="stylesheet">
  <link href="assets/js/google-code-prettify/prettify.css" rel="stylesheet">
  <link href="assets/css/camera.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300|Open+Sans:400,300,300italic,400italic" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/color/success.css" rel="stylesheet">

  <!-- fav and touch icons -->
  <link rel="shortcut icon" href="assets/ico/favicon.ico">
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
  <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

  <!-- =======================================================
    Theme Name: Scaffold
    Theme URL: https://bootstrapmade.com/scaffold-bootstrap-metro-style-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>

<body>

  <header>
    <!-- Navbar
    ================================================== -->
    <div class="navbar navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
          <!-- logo -->
          <a class="brand logo" href="index.php">
            <img src="assets/img/htl_spg.jpg" alt="" />
          </a>
          <!-- end logo -->

          <!-- top menu -->
          <div>
            <nav>
              <ul class="nav topnav">
                <li class="dropdown success active">
                  <a href="ADMIN.php"><i class="icon-home icon-white"></i> HOME </a>
                  <ul class="dropdown-menu">
                   
                  </ul>
                </li>
                <li class="dropdown primary">
                  <a href="InputDtKmr.php"><i class="icon-star icon-white"></i> DATA KAMAR </a> 
				
                </li>
                <!--li class="dropdown danger">
                  <a href="Up_fasilitas.php"><i class="icon-leaf icon-white"></i> FASILITAS KAMAR </a>
                </li-->
				
				 <li class="dropdown danger">
                  <a href="Up_fashotel.php"><i class="icon-leaf icon-white"></i> FASILITAS HOTEL </a>
	
				
		</li>
                
 		 <li class="dropdown info">
			   <a href="index.php"><i class="icon-camera/img3 icon-white"></i> LOG OUT</a>
                  <ul class="dropdown-menu">
                    
                  </ul>
                </li>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </header>

  <section id="intro">
    <div class="jumbotron masthead">

      <div class="container">
        <div class="row">
			<br/><br/>
				<form action="Simpan_FasHotel.php" method="POST" enctype="multipart/form-data">
					<fieldset>
					<legend>INPUT DATA FASILITAS HOTEL</legend>
					<table border="0">
					<tr>
					<td>
					<label>NAMA PEMILIK :</label>
					<input type="text" name="nm_pemilik" placeholder="input nama pemilik..." />
					
					<label>TELP:</label>
					<input type="text" name="telp" placeholder="input nomor telepon..." />
					</td>
					<td>
					<label>ALAMAT:</label>
					<input type="text" name="alamat" placeholder="input alamat ..." />
					
					<label> KOLAM RENANG :</label>
					<input type="file" name="klm_renang" placeholder="input gambar..." />	
					</td>
					<td>
					<label> RUANG SERBAGUNA :</label>
					<input type="file" name="r_serbaguna" placeholder="input gambar..." />	
					
					<label> RESTORAN :</label>
					<input type="file" name="resto" placeholder="input gambar..." />	
					
					<input type="submit" name="save" value ="save" >
					</tr>
					</td>
					</table>
					</fieldset>
				</form>
			<table>
				<h1> FASILITAS HOTEL </h1>
				<table border ="1" cellpanding="8"
				cellspacing="0">
				<tr>
					<td> NO </td>
					<td> NAMA PEMILIK</td>
					<td> TELP </td>
					<td> ALAMAT </td>
					<td> KOLAM RENANG </td>
					<td> RUANG SERBAGUNA </td>
					<td> RESTORAN </td>
				<tr>
				<?php
				include_once('koneksi.php');
				$query=mysqli_query($conn, "SELECT * FROM tb_fashotel ORDER BY nm_pemilik asc");
				$no = 1;
				while ($row = mysqli_fetch_assoc($query)){
				
				 ?>
				 <tr>
					<td><?php echo $no++; ?></td>
					<td><?php echo $row["nm_pemilik"]; ?></td>
					<td><?php echo $row["telp"]; ?></td>
					<td><?php echo $row["alamat"]; ?></td>
					
					<td><img src="images/<?php echo $row["klm_renang"]; ?>" width="100"></td>
					<td><img src="images/<?php echo $row["r_serbaguna"]; ?>" width="100"></td>
					<td><img src="images/<?php echo $row["resto"]; ?>" width="100"></td>
				 </tr>
				<?php }?>
				</table>
          
                  </div>
                </div>
              </div>
           

          </div>
        </div>
      </div>
    </div>
  </section>


      <div class="row">
        <div class="span12">
          <div class="divider"></div>
        </div>
      </div>
      <!-- end divider -->


      <div class="row">
        <div class="span12">
          <h3><a class="btn btn-large btn-success" href="Simpan_FasHotel"><i class="m-icon-big-swapdown m-icon-white"></i></a> Recent works</h3>
		<!--sebagian coding di cut -->
				
          <div id="latest-work" class="carousel btleft">
            <div class="carousel-wrapper">

              <ul class="portfolio-home da-thumbs">
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work1.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>

                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work2.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work3.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work4.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work5.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work6.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work7.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work8.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer
 ================================================== -->
  <footer class="footer">
    <div class="container">
      <div class="row">
        <div class="span4">
          <div class="widget">
            <h4>About us</h4>
            <address>
					<strong>Scaffold company, Inc.</strong><br>
					445 Mypark Ave, Suite 800<br>
					Jakarta, Indonesia 14210<br>
					<abbr title="Phone">P:</abbr> (123) 456-7890
					</address>

            <address>
					<strong>Contact us</strong><br>
					<a href="mailto:#">hello@websitename.com</a>
					</address>
          </div>
        </div>
        <div class="span4">
          <div class="widget">
            <h4>Browse pages</h4>
            <ul class="nav nav-list regular">
              <li class="nav-header">More from us</li>
              <li><a href="#">Work for us</a></li>
              <li><a href="#">Creative process</a></li>
              <li><a href="#">Case study</a></li>
              <li class="nav-header">Quick links</li>
              <li><a href="#">Scaffold awwards</a></li>
              <li><a href="#">Meet the team</a></li>
            </ul>
          </div>
        </div>
        <div class="span4">
          <div class="widget">
            <h4>Get email updates</h4>
            <form class="form-horizontal" action="#" method="post">
              <fieldset>
                <p>
                  Sign up for email updates and we'll plant a tree for you through Trees for the Future.
                </p>

                <div class="input-prepend input-append">
                  <input class="span2" id="appendedPrependedInput" type="text" placeholder="Email">
                  <button class="btn btn-inverse" type="submit">Subscribe!</button>
                </div>
              </fieldset>
            </form>
            <ul class="social_small">
              <li class="facebook first"><a href="#" title="Facebook">Facebook</a></li>
              <li class="twitt"><a href="#" title="Twitter">Twitter</a></li>
              <li class="googleplus"><a href="#" title="google plus">Google plus</a></li>
              <li class="flickr"><a href="#" title="flickr">Flickr</a></li>
              <li class="dribbble"><a href="#" title="Dribbble">Dribbble</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div class="verybottom">
      <div class="container">
        <div class="row">
          <div class="span6">
            <p>&copy; Scaffold - All right reserved</p>
          </div>
          <div class="span6">
            <div class="pull-right">
              <div class="credits">
       
                Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </footer>

  <script src="assets/js/jquery-1.8.2.min.js"></script>
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <script src="assets/js/google-code-prettify/prettify.js"></script>
  <script src="assets/js/modernizr.js"></script>
  <script src="assets/js/bootstrap.js"></script>
  <script src="assets/js/jquery.elastislide.js"></script>
  <script src="assets/js/jquery.flexslider.js"></script>
  <script src="assets/js/jquery.prettyPhoto.js"></script>
  <script src="assets/js/application.js"></script>
  <script src="assets/js/hover/jquery-hover-effect.js"></script>
  <script src="assets/js/hover/setting.js"></script>
  <script src="assets/js/camera/camera.min.js"></script>
  <script src="assets/js/camera/setting.js"></script>

  <!-- Template Custom JavaScript File -->
  <script src="assets/js/custom.js"></script>

</body>

</html>
