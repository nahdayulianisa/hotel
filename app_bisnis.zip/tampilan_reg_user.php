<?php
include('koneksi.php'); // Memasuk-kan skrip Login 
 
if(isset($_SESSION['reservasi'])){
header("location: user.php");
}
?>

<style type="text/css">
<!--
.style3 {font-size: 24px}
-->
</style>
<form name="form1" method="post" action="index.php?register2=success">
<table width="400" border="0">
<tr>
<td colspan="2"><span class="style3">Register</span></td>
</tr>
<tr>
<td>Nama : </td>
<td><input name="nm_tamu" type="text" id="nm_tamu"></td>
</tr>
<td>Alamat : </td>
<td><input name="alamat" type="text" id="alamat"></td>
</tr>
<tr>
<td>Email : </td>
<td><input name="e_mail" type="text" id="e_mail"></td>
</tr>
<tr>
<td>Password : </td>
<td><input name="pass" type="password" id="pass"></td>
</tr>
<tr>
<td >Confirm Password : </td>
<td><input name="c_pass" type="password" id="c_pass"></td>
</tr>
<tr>
<td colspan="2"> </td>
</tr>
<tr>
<td colspan="2"><input type="submit" name="Submit" value="Register"></td>
</tr>
</table>
</form>
<?php mysql_close($connect); ?>
 
<!DOCTYPE html>

<!--html>
  <head>
    <title>LOGIN</title>
	
	<!-- Skrip CSS -->
   <!--link rel="stylesheet" href="style_login.css"/>
  
  </head>	
  <body>
	<div class="container">
		<div class="main">
	      <form action="USER.php" method="post">
			<h2>SELAMAT DATANG DI RESERVASI HOTEL </h2><hr/>
			<h1>Silahkan login terlebih dahulu...</h1>			
			
			<label>id:</label>
			<input id="id_tamu" name="username" placeholder="id_tamu" type="text">
			
			<label>user name :</label>
			<input id="nm_tamu" name="nm_tamu" placeholder="**********" type="text">
			
			<label>alamat :</label>
			<input id="alamat" name="alamat" placeholder="**********" type="text">
			
			<input type="submit" name="submit" id="submit" value="Login">
		  </form>
		</div>
   </div>
 
  </body>
</html-->

