<?php
include('login.php'); // Memasuk-kan skrip Login 
 
if(isset($_SESSION['reservasi'])){
header("location: login.php");
}
?>
 
<!DOCTYPE html>
<html>
  <head>
    <title>LOGIN</title>
	
	<!-- Skrip CSS -->
   <link rel="stylesheet" href="style_login.css"/>
  
  </head>	
  <body>
	<div class="container">
		<div class="main">
	      <form action="ADMIN.php" method="post">
			<h2>SELAMAT DATANG DI RESERVASI HOTEL </h2><hr/>
			<h1>Silahkan login terlebih dahulu...</h1>			
			
			<label>Username :</label>
			<input id="username" name="username" placeholder="username" type="text">
			
			<label>Password :</label>
			<input id="password" name="password" placeholder="**********" type="password">
			
			<input type="submit" name="submit" id="submit" value="Login">
		  </form>
		</div>
   </div>
 
  </body>
</html>

