<?php
// include database connection file
include_once("koneksi.php");

// Get id_kmr from URL to delete that user
$id_kmr = $_GET['id_kmr'];

// Delete user row from table based on given id_kmr
$result = mysqli_query($conn, "DELETE FROM tb_indtkmr WHERE id_kmr=$id_kmr");

// After delete redirect to Home, so that latest user list will be displayed.
header("Location:InputDtKmr.php");
?>