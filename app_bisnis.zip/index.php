<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Reservasi_Hotel_Soppeng</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- styles -->
  <link href="assets/css/bootstrap.css" rel="stylesheet">
  <link href="assets/css/bootstrap-responsive.css" rel="stylesheet">
  <link href="assets/css/docs.css" rel="stylesheet">
  <link href="assets/css/prettyPhoto.css" rel="stylesheet">
  <link href="assets/js/google-code-prettify/prettify.css" rel="stylesheet">
  <link href="assets/css/camera.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300|Open+Sans:400,300,300italic,400italic" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/color/success.css" rel="stylesheet">

  <!-- fav and touch icons -->
  <link rel="shortcut icon" href="assets/ico/favicon.ico">
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
  <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

  <!-- =======================================================
    Theme Name: Scaffold
    Theme URL: https://bootstrapmade.com/scaffold-bootstrap-metro-style-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>

<body>

  <header>
    <!-- Navbar
    ================================================== -->
    <div class="navbar navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
          <!-- logo -->
          <a class="brand logo" href="index.php">
            <img src="assets/img/htl_spg.jpg" alt="" />
          </a>
          <!-- end logo -->

          <!-- top menu -->
          <div>
            <nav>
              <ul class="nav topnav">
                <li class="dropdown success active">
                  <a href="index.php"><i class="icon-home icon-white"></i> Home</a>
                  <ul class="dropdown-menu">
                    
                  </ul>
                </li>
                <!--li class="dropdown primary">
                  <a href="ADMIN.html"><i class="icon-star icon-white"></i> DATA KAMAR </a>
                  <!--ul class="dropdown-menu">
                    <li><a href="overview.html">No Kamar </a></li>
                    <li><a href="scaffolding.html">Tipe</a></li>
                    <li><a href="base-css.html">Tanggal Pembayaran</a></li>
                    <li><a href="components.html">Harga Sewa</a></li>
                    <li><a href="javascript.html">Status Kamar</a></li>
                    <!--li class="dropdown"><a href="#">3rd level</a-->
                      <!--ul class="dropdown-menu sub-menu">
                        <li><a href="#">Example menu</a></li>
                        <li><a href="#">Example menu</a></li>
                        <li><a href="#">Example menu</a></li>
                      </ul>
                    </li>
                  </ul-->
                <!--/li>
                <li class="dropdown danger">
                  <a href="#"><i class="icon-leaf icon-white"></i> DATA FASILITAS </a>
                  <ul class="dropdown-menu">
                    <li><a href="about.html">No Kuitansi </a></li>
                    <li><a href="services.html">Tanggal Pembayaran</li>
                    <li><a href="pricingtable.html">Jumlah</a></li>
                    <li><a href="faq.html">Terbilang</a></li>
                    <li><a href="fullwidth.html">Keterangan</a></li>
                    <li><a href="404.html">id_reservasi</a></li>
                  </ul>
                </li>
                <li class="dropdown warning">
                  <a href="#"><i class="icon-camera icon-white"></i> RESERVASI </a>
                  <ul class="dropdown-menu">
                    <li class="dropdown"><a href="#">Portfolio type 1</a>
                      <ul class="dropdown-menu sub-menu">
                        <li><a href="portfolio-alt1-2cols.html">2 columns</a></li>
                        <li><a href="portfolio-alt1-3cols.html">3 columns</a></li>
                        <li><a href="portfolio-alt1-4cols.html">4 columns</a></li>
                      </ul>
                    </li>
                    <li class="dropdown"><a href="#">Portfolio type 2</a>
                      <ul class="dropdown-menu sub-menu">
                        <li><a href="portfolio-alt2-2cols.html">2 columns</a></li>
                        <li><a href="portfolio-alt2-3cols.html">3 columns</a></li>
                        <li><a href="portfolio-alt2-4cols.html">4 columns</a></li>
                      </ul>
                    </li>
                    <li><a href="portfolio-alt3.html">Portfolio type 3</a></li>
                    <li><a href="portfolio-detail.html">Portfolio detail</a></li>
                  </ul>
                </li-->
			 <li class="dropdown info">
			   <a href="index.php"><i class="icon-camera/img3 icon-white"></i> LOGIN</a>
                  <ul class="dropdown-menu">
                    <li><a href="tampilan_login.php">ADMIN</a></li>
					<li><a href="tampilan_log_user.php">USER</a></li>
                    <!--li><a href="tampilan_log_user.php">USER</a></li-->
                  </ul>
                </li>
                <li class="dropdown inverse">
                <!--li class="dropdown info"-->
                  <!--a href="#"><i class="icon-bullhorn icon-white"></i> Blog</a>
                  <ul class="dropdown-menu">
                    <li><a href="blog_left_sidebar.html">Blog left sidebar</a></li>
                    <li><a href="blog_right_sidebar.html">Blog right sidebar</a></li>
                    <li><a href="post_left_sidebar.html">Post left sidebar</a></li>
                    <li><a href="post_right_sidebar.html">Post right sidebar</a></li>
                  </ul>
                </li>
                <li class="inverse">
                  <a href="contact.html"><i class="icon-envelope icon-white"></i> Contact</a>
                </li>
              </ul-->
            </nav>
          </div>
          <!-- end menu -->
        </div>
      </div>
    </div>
  </header>

  <section id="intro">
    <div class="jumbotron masthead">

      <div class="container">
        <div class="row">
          <div class="span12">
            <div class="camera_wrap camera_black_skin" id="camera_wrap_2">
              <div data-thumb="assets/img/index.jpg" data-src="assets/img/index.jpg">
                <div class="camera_caption fadeFromBottom">
                  <h2>HOTEL SOPPENG </h2>
                  <div class="hidden-phone">
                    <p>
                      Memiliki 3 type kamar yaitu standard, superior dan deluxe
                    </p>
                  </div>
                </div>
              </div>
              <div data-thumb="assets/img/depan hotel.jpg" data-src="assets/img/depan hotel.jpg">
                <div class="camera_caption fadeFromBottom">
                  
                  <div class="hidden-phone">
                    <p>
                      Memiliki beberapa fasilitas umum seperti
					  kolam renang,resto dan ruang serba guna
                    </p>
                  </div>
                </div>
              </div>
              <!--div data-thumb="assets/img/slides/camera/img3.jpg" data-src="assets/img/slides/camera/img3.jpg">
                <div class="camera_caption fadeFromBottom">
                  <h2>Metro style</h2>
                  <div class="hidden-phone">
                    <p>
                      Lorem ipsum dolor sit amet, dicam singulis in ius, eu timeam aperiam pri. His suas solum legimus eu, sea an duis habemus urbanitas. No sapientem consetetur sit an.
                    </p>
                  </div>
                </div>
              </div>
              <div data-thumb="assets/img/slides/camera/img4.jpg" data-src="assets/img/slides/camera/img4.jpg">
                <div class="camera_caption fadeFromBottom">
                  <h2>Lot of features</h2>
                  <div class="hidden-phone">
                    <p>
                      Sit et laudem aperiri argumentum. Vim laboramus instructior eu, minim aliquid accusata ut est, sea ut ridens causae quaerendum. Ea vide posidonium usu qui ad pertinax.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <!-- #camera_wrap_1 -->

          </div>
        </div>
      </div>
    </div>
  </section>


  <!--div class="container">
    <div class="row">
      <div class="span12">
        <div class="tagline">
          <div class="row">
            <div class="span6">
              <div class="tagline_text">
                <h2>Scaffold will <span class="text-success">pimp up</span> your website quickly</h2>
                <div class="tag_list">
                  <ul>
                    <li><span><i class="icon-fire"></i> Hottest price on the net</span></li>
                    <li><span><i class="icon-gift"></i> More than expected</span></li>
                    <li><span><i class="icon-plane"></i> Flying out of the crowd</span></li>
                  </ul>
                </div>
              </div>
            </div>

            <div class="span6">
              <div class="btn-toolbar cta">
                <a class="btn btn-large btn-danger" href="#"><i class="m-icon-big-swapright m-icon-white"></i> Our pricing</a>
                <a class="btn btn-large btn-success" href="#"><i class="m-icon-big-swapdown m-icon-white"></i> Download now</a>
              </div>
            </div>


          </div>
        </div>
      </div>

    </div>
  </div>

  <!-- end tagline -->

  <!--section id="maincontent">
    <div class="container">

      <div class="row">
        <div class="span3">
          <h3 class="heading-success"><span class="btn btn-large btn-success"><i class="m-icon-big-swapright m-icon-white"></i></span>&nbsp;&nbsp;Main features</h3>
          <p>Aenean sodales augue ac lacus hendrerit sed rhoncus erat hendrerit. Praesent eleifend sodales felis, in congue purus scelerisque eget.</p>
        </div>
        <div class="span3">
          <div class="well well-primary box">
            <img src="assets/img/icons/box-1-white.png" alt="" />
            <h3>Responsive bootstrap</h3>
            <p>
              Dolorem adipiscing definiebas ut nec. Dolore consectetuer eu vim, elit molestie ei has, petentium imperdiet in pri. Mel virtute efficiantur ne zril.
            </p>
            <a href="#">Read more</a>
          </div>
        </div>
        <div class="span3">
          <div class="well well-success box">
            <img src="assets/img/icons/box-2-white.png" alt="" />
            <h3>With metro taste</h3>
            <p>
              Ad sit option intellegat, unum populo comprehensam ut sed. Copiosae corrumpit qui ex, duo nullam feugait qualisque at an dicit saperet.
            </p>
            <a href="#">Read more</a>
          </div>
        </div>
        <div class="span3">
          <div class="well well-warning box">
            <img src="assets/img/icons/box-3-white.png" alt="" />
            <h3>Well documented</h3>
            <p>
              Ne vix clita integre expetenda, eos cetero numquam no, in sea omnes detracto. Ne iriure habemus maiestatis mei. Postea euripidis contentiones.
            </p>
            <a href="#">Read more</a>
          </div>
        </div>
      </div>

    </div>
  </section>


  <section id="bottom">
    <div class="container">

      <!-- divider -->
      <div class="row">
        <div class="span12">
          <div class="divider"></div>
        </div>
      </div>
      <!-- end divider -->


      <div class="row">
        <div class="span12">
          <h3><a class="btn btn-large btn-success" href="#"><i class="m-icon-big-swapdown m-icon-white"></i></a> Recent works</h3>

          <div id="latest-work" class="carousel btleft">
            <div class="carousel-wrapper">

              <ul class="portfolio-home da-thumbs">
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work1.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>

                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work2.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work3.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work4.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work5.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work6.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work7.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="thumbnail">
                    <div class="image-wrapp">
                      <img src="assets/img/dummies/work8.jpg" alt="Portfolio name" title="" />
                      <article class="da-animate da-slideFromRight" style="display: block;">
                        <a class="link_post" href="portfolio-detail.html"><img src="assets/img/icons/link_post_icon.png" alt="" /></a>
                        <span><a class="zoom" data-pretty="prettyPhoto" href="assets/img/dummies/big1.jpg"><img src="assets/img/icons/zoom_icon.png" alt="Portfolio name" title="Portfolio name" /></a></span>
                      </article>
                    </div>
                    <div class="caption">
                      <h5>Portfolio name</h5>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer
 ================================================== -->
  <footer class="footer">
    <div class="container">
      <div class="row">
        <div class="span4">
          <div class="widget">
            <h4>About us</h4>
            <address>
					<strong>Scaffold company, Inc.</strong><br>
					445 Mypark Ave, Suite 800<br>
					Jakarta, Indonesia 14210<br>
					<abbr title="Phone">P:</abbr> (123) 456-7890
					</address>

            <address>
					<strong>Contact us</strong><br>
					<a href="mailto:#">hello@websitename.com</a>
					</address>
          </div>
        </div>
        <div class="span4">
          <div class="widget">
            <h4>Browse pages</h4>
            <ul class="nav nav-list regular">
              <li class="nav-header">More from us</li>
              <li><a href="#">Work for us</a></li>
              <li><a href="#">Creative process</a></li>
              <li><a href="#">Case study</a></li>
              <li class="nav-header">Quick links</li>
              <li><a href="#">Scaffold awwards</a></li>
              <li><a href="#">Meet the team</a></li>
            </ul>
          </div>
        </div>
        <div class="span4">
          <div class="widget">
            <h4>Get email updates</h4>
            <form class="form-horizontal" action="#" method="post">
              <fieldset>
                <p>
                  Sign up for email updates and we'll plant a tree for you through Trees for the Future.
                </p>

                <div class="input-prepend input-append">
                  <input class="span2" id="appendedPrependedInput" type="text" placeholder="Email">
                  <button class="btn btn-inverse" type="submit">Subscribe!</button>
                </div>
              </fieldset>
            </form>
            <ul class="social_small">
              <li class="facebook first"><a href="#" title="Facebook">Facebook</a></li>
              <li class="twitt"><a href="#" title="Twitter">Twitter</a></li>
              <li class="googleplus"><a href="#" title="google plus">Google plus</a></li>
              <li class="flickr"><a href="#" title="flickr">Flickr</a></li>
              <li class="dribbble"><a href="#" title="Dribbble">Dribbble</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div class="verybottom">
      <div class="container">
        <div class="row">
          <div class="span6">
            <p>&copy; Scaffold - All right reserved</p>
          </div>
          <div class="span6">
            <div class="pull-right">
              <div class="credits">
                <!--
                  All the links in the footer should remain intact.
                  You can delete the links only if you purchased the pro version.
                  Licensing information: https://bootstrapmade.com/license/
                  Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Scaffold
                -->
                Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </footer>

  <script src="assets/js/jquery-1.8.2.min.js"></script>
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <script src="assets/js/google-code-prettify/prettify.js"></script>
  <script src="assets/js/modernizr.js"></script>
  <script src="assets/js/bootstrap.js"></script>
  <script src="assets/js/jquery.elastislide.js"></script>
  <script src="assets/js/jquery.flexslider.js"></script>
  <script src="assets/js/jquery.prettyPhoto.js"></script>
  <script src="assets/js/application.js"></script>
  <script src="assets/js/hover/jquery-hover-effect.js"></script>
  <script src="assets/js/hover/setting.js"></script>
  <script src="assets/js/camera/camera.min.js"></script>
  <script src="assets/js/camera/setting.js"></script>

  <!-- Template Custom JavaScript File -->
  <script src="assets/js/custom.js"></script>

</body>

</html>
