-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2019 at 09:54 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_fashotel`
--

CREATE TABLE IF NOT EXISTS `tb_fashotel` (
  `id_hotel` int(3) NOT NULL AUTO_INCREMENT,
  `nm_pemilik` varchar(25) NOT NULL,
  `telp` int(12) NOT NULL,
  `alamat` varchar(25) NOT NULL,
  `klm_renang` varchar(25) DEFAULT NULL,
  `r_serbaguna` varchar(25) DEFAULT NULL,
  `resto` varchar(25) DEFAULT NULL,
  KEY `id_hotel` (`id_hotel`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tb_fashotel`
--

INSERT INTO `tb_fashotel` (`id_hotel`, `nm_pemilik`, `telp`, `alamat`, `klm_renang`, `r_serbaguna`, `resto`) VALUES
(3, 'REFNI AYU SARI', 2147483647, 'TAKALALA', 'kolam renang 2.jpg', 'serbaguna 2.jpg', 'restoran.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_indtkmr`
--

CREATE TABLE IF NOT EXISTS `tb_indtkmr` (
  `id_kmr` int(6) NOT NULL AUTO_INCREMENT,
  `kd_kmr` varchar(5) NOT NULL,
  `nm_kmr` varchar(25) NOT NULL,
  `hrg_kmr` int(12) NOT NULL,
  `gambar` varchar(25) NOT NULL,
  `fasilitas` varchar(100) NOT NULL,
  KEY `id_kmr` (`id_kmr`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tb_indtkmr`
--

INSERT INTO `tb_indtkmr` (`id_kmr`, `kd_kmr`, `nm_kmr`, `hrg_kmr`, `gambar`, `fasilitas`) VALUES
(22, 'A01', 'STANDAR', 350000, 'kamar 2.jpg', 'TV,AC'),
(23, 'B02', 'SUPERIOR', 550000, 'kamar 1.jpg', 'TV,WIFI,AC'),
(24, 'A05', 'STANDAR', 350000, 'kamar 1.jpg', 'TV,AC');

-- --------------------------------------------------------

--
-- Table structure for table `tb_infasilitas`
--

CREATE TABLE IF NOT EXISTS `tb_infasilitas` (
  `id_fasilitas` int(25) NOT NULL AUTO_INCREMENT,
  `nm_fasilitas` varchar(30) NOT NULL,
  PRIMARY KEY (`id_fasilitas`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tb_infasilitas`
--

INSERT INTO `tb_infasilitas` (`id_fasilitas`, `nm_fasilitas`) VALUES
(1, 'TV'),
(2, 'WIFI');

-- --------------------------------------------------------

--
-- Table structure for table `tb_login`
--

CREATE TABLE IF NOT EXISTS `tb_login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `id_user` int(12) NOT NULL AUTO_INCREMENT,
  `resto` varchar(25) NOT NULL,
  `r_serbaguna` varchar(25) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_reservasi`
--

CREATE TABLE IF NOT EXISTS `tb_reservasi` (
  `nm_tamu` varchar(25) NOT NULL,
  `type_kmr` varchar(15) NOT NULL,
  `booking` varchar(25) NOT NULL,
  `total` int(12) NOT NULL,
  `byr` int(12) NOT NULL,
  `pembayaran` varchar(25) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `id_reservasi` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_reservasi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tb_reservasi`
--

INSERT INTO `tb_reservasi` (`nm_tamu`, `type_kmr`, `booking`, `total`, `byr`, `pembayaran`, `keterangan`, `id_reservasi`) VALUES
('Sri Dewi', 'A01', '1 hari', 350000, 350000, 'Cash', 'Lunas', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE IF NOT EXISTS `tb_user` (
  `id_tamu` int(16) NOT NULL AUTO_INCREMENT,
  `nm_tamu` varchar(25) NOT NULL,
  `alamat` varchar(25) NOT NULL,
  `e_mail` varchar(30) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `c_pass` varchar(20) NOT NULL,
  PRIMARY KEY (`id_tamu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
