<?php
include('login.php'); // Memasuk-kan skrip Login 
 
if(isset($_SESSION['reservasi'])){
header("location: login.php");
}
?>
 
<!DOCTYPE html>
<html>
  <head>
    <title>LOGIN</title>
	
	<!-- Skrip CSS -->
   <link rel="stylesheet" href="style_login.css"/>
  
  </head>	
  <body>
	<div class="container">
		<div class="main">
	      <form action="USER.php" method="post">
			<h2>SELAMAT DATANG DI RESERVASI HOTEL </h2><hr/>
			<h1>Silahkan login terlebih dahulu...</h1>			
			
			<label>id:</label>
			<input id="id_tamu" name="username" placeholder="id_tamu" type="text">
			
			<label>user name :</label>
			<input id="nm_tamu" name="nm_tamu" placeholder="**********" type="text">
			

			
			<input type="submit" name="submit" id="submit" value="Login">
		  </form>
		</div>
   </div>
 
  </body>
</html>

