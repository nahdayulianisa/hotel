<?php

//include_once('koneksi.php');
include ("koneksi.php");
$nameFileklm = $_FILES['klm_renang']['name'];
$nameFilersb = $_FILES['r_serbaguna']['name'];
$nameFilerst = $_FILES['resto']['name'];
$tmpklm = $_FILES['klm_renang']['tmp_name'];
$tmprsb = $_FILES['r_serbaguna']['tmp_name'];
$tmprst = $_FILES['resto']['tmp_name'];
$path = "images/";
 
$extenstionklm = pathinfo($_FILES['klm_renang']['name'], PATHINFO_EXTENSION);
$extenstionrsb = pathinfo($_FILES['r_serbaguna']['name'], PATHINFO_EXTENSION);
$extenstionrst = pathinfo($_FILES['resto']['name'], PATHINFO_EXTENSION);
 
if 
	($_FILES['klm_renang']['size'] > 512000) {
    echo "File terlalu besar";
	return;
	}
	
if
	($_FILES['r_serbaguna']['size'] > 512000) {
    echo "File terlalu besar";
	return;
	}
if
	($_FILES['resto']['size'] > 512000) {
    echo "File terlalu besar";
   return;
	}
		

 
move_uploaded_file($tmpklm, $path . $nameFileklm);
move_uploaded_file($tmprsb, $path . $nameFilersb);
$save = move_uploaded_file($tmprst, $path . $nameFilerst);
if ($save) {
   $nm_pemilik = $_POST['nm_pemilik'];
    //$nm_pemilik = "A";
	$telp = $_POST['telp'];
	//$telp = "B";
	$alamat = $_POST['alamat'];
	//$alamat = "C";
	$klm_renang = $_FILES ['klm_renang']['name'];
	$r_serbaguna = $_FILES ['r_serbaguna']['name'];
	$resto = $_FILES['resto']['name'];
   // $sql = 'insert into tb_fashotel(nm_pemilik,telp,alamat,klm_renang,r_serbaguna,resto) 
   // values ( '.$nm_pemilik.','.$telp.','.$alamat.','.$klm_renang.','.$r_serbaguna.','.$resto.')';
	$sql = "insert into tb_fashotel (nm_pemilik,telp,alamat,klm_renang,r_serbaguna,resto)" . 
    "values ( '$nm_pemilik','$telp','$alamat','$klm_renang','$r_serbaguna','$resto')";
    mysqli_query($conn, $sql);
    echo "File berhasil di upload<br>";
	header("location: Up_fashotel.php");
} else {
    echo "Upload FIle gagal.";
 }
?> 









//include_once('koneksi.php');

//if(isset($_POST["save"])){
	//$nm_pemilik = $_POST['nm_pemilik'];
	//$telp = $_POST['telp'];
	//$alamat = $_POST['alamat'];
	//$klm_renang = $_POST ['klm_renang'];
	//$r_serbaguna = $_POST ['r_serbaguna'];
	//$resto = $_POST ['resto'];
 //if(!empty($nm_pemilik)){
  //$sql = "insert into tb_fashotel ( nm_pemilik,telp,alamat,klm_renang,r_serbaguna,resto)" . 
    //"values ('$nm_pemilik','$telp','$alamat','$klm_renang','$r_serbaguna','$resto')";
  //mysqli_query($conn, $sql);
  //header('location:Up_fashotel.html');
 //}else{
  //echo 'Semua data diperlukan. Harap isi semua.!';
 //}
//}
?>
