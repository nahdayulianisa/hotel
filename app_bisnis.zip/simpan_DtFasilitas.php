
<?php

include_once('koneksi.php');

if(isset($_POST["save"])){
	//$id_fasilitas = $_POST['id_fasilitas'];
	$nm_fasilitas = $_POST['nm_fasilitas'];
 if(!empty($nm_fasilitas)){
  $sql = "insert into tb_infasilitas(nm_fasilitas)" . 
    "values ('$nm_fasilitas')";
  mysqli_query($conn, $sql);
  header('location:Up_fasilitas.html');
 }else{
  echo 'Semua data diperlukan. Harap isi semua.!';
 }
}
?>