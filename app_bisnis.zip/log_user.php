<?php
$host   = 'localhost';
$db_name  = 'db_hotel';
$db_user  = 'root';
$db_pass  = '';

$conn = mysqli_connect($host,$db_user,$db_pass,$db_name);
if(mysqli_connect_errno($conn)){
 echo 'Koneksi Gagal';
}
?>
<?php
session_start(); // Memulai Session
$error=''; // Variabel untuk menyimpan pesan error
if (isset($_POST['login'])) {
	if (empty($_POST['username']) || empty($_POST['password'])) {
			$error = "Username or Password is invalid";
	}
	else
	{
		// Variabel username dan password
		$username=$_POST['username'];
		$password=$_POST['password'];
		// Membangun koneksi ke database
		$connection = mysql_connect("localhost", "root", "");
		// Mencegah MySQL injection 
		$username = stripslashes($username);
		$password = stripslashes($password);
		$username = mysql_real_escape_string($username);
		$password = mysql_real_escape_string($password);
		// Seleksi Database
		$db = mysql_select_db("db_hotel", $connection);
		// SQL query untuk memeriksa apakah karyawan terdapat di database?
		$query = mysql_query("select * from tb_login where username='$username' AND  password='$password'", $connection);
		$rows = mysql_num_rows($query);
			if ($rows == 1) {
				$_SESSION['reservasi']=$username; // Membuat Sesi/session
				header("location: ADMIN.php"); // Mengarahkan ke halaman profil
		} else {
				$error = "Username atau Password belum terdaftar";
				}
				mysql_close($connection); // Menutup koneksi
				  header("location:index.php");
	}
}
?>

