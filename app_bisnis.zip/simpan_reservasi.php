<?php


include ("koneksi.php");

if(isset($_POST["save"])){
//if ($save) {
	$nm_tamu = $_POST['nm_tamu'];
	$type_kmr = $_POST['type_kmr'];
	$booking = $_POST['booking'];
	$total = $_POST ['total'];
	$byr = $_POST ['byr'];
	$pembayaran = $_POST ['pembayaran'];
	$keterangan = $_POST ['keterangan'];
   //$move = move_uploaded_file($_FILES['gambar']['tmp_name'], 'C:/xampp/htdocs/app_bisnis/image/'.$fileName); //save image to the folder

if(!empty($nm_tamu)){
 $sql = "insert into tb_reservasi ( nm_tamu,type_kmr,booking,total,byr,pembayaran,keterangan)". 
 "values ('$nm_tamu','$type_kmr','$booking','$total','$byr','$pembayaran','$keterangan')";
 mysqli_query($conn, $sql);
   //$save = mysqli_query($conn, $sql);
  // echo "File berhasil di upload<br>";
  header("location:reservasi.php");
 }else{
echo 'Semua data diperlukan. Harap isi semua.!';	 
 // echo "Upload FIle gagal.";;

}
}
?>